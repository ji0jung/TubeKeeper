# Integration Contract

## 개요
각 단위(Unit) 간의 통합을 위한 API 엔드포인트와 메소드를 정의합니다.

## Unit 1: User Authentication & Profile Management

### Authentication Service API
```
POST /api/auth/register
- 이메일 회원가입 요청
- Body: { email, gender?, birthYear? }
- Response: { success, message }

POST /api/auth/verify-registration
- 회원가입 인증 코드 확인
- Body: { email, verificationCode }
- Response: { success, token, user }

POST /api/auth/login
- 로그인 요청 (인증 코드 발송)
- Body: { email }
- Response: { success, message }

POST /api/auth/verify-login
- 로그인 인증 코드 확인
- Body: { email, verificationCode }
- Response: { success, token, user }

POST /api/auth/logout
- 로그아웃
- Headers: { Authorization: Bearer token }
- Response: { success }

POST /api/auth/refresh-session
- 세션 자동 연장
- Headers: { Authorization: Bearer token }
- Response: { success, newToken }

DELETE /api/auth/account
- 회원 탈퇴
- Headers: { Authorization: Bearer token }
- Response: { success }
```

### Profile Service API
```
GET /api/profile
- 프로필 정보 조회
- Headers: { Authorization: Bearer token }
- Response: { user: { email, gender, birthYear, language } }

PUT /api/profile
- 프로필 정보 수정
- Headers: { Authorization: Bearer token }
- Body: { gender?, birthYear?, language? }
- Response: { success, user }
```

## Unit 2: Category Management

### Category Service API
```
GET /api/categories
- 사용자 카테고리 목록 조회
- Headers: { Authorization: Bearer token }
- Response: { categories: [{ id, name, cardCount, isDeletable }] }

POST /api/categories
- 새 카테고리 생성
- Headers: { Authorization: Bearer token }
- Body: { name }
- Response: { success, category: { id, name } }

PUT /api/categories/:id
- 카테고리 이름 수정
- Headers: { Authorization: Bearer token }
- Body: { name }
- Response: { success, category }

DELETE /api/categories/:id
- 카테고리 삭제 (빈 카테고리만)
- Headers: { Authorization: Bearer token }
- Response: { success }
```

## Unit 3: Card Creation & Management

### Card Service API
```
POST /api/cards
- 새 카드 생성
- Headers: { Authorization: Bearer token }
- Body: { youtubeUrl, categoryId }
- Response: { success, card: { id, title, thumbnail, ... } }

GET /api/cards/:id
- 카드 상세 조회
- Headers: { Authorization: Bearer token }
- Response: { card: { id, title, thumbnail, script, summary, tags, memo, category } }

PUT /api/cards/:id
- 카드 정보 수정
- Headers: { Authorization: Bearer token }
- Body: { memo?, tags?, categoryId? }
- Response: { success, card }

DELETE /api/cards/:id
- 카드 삭제
- Headers: { Authorization: Bearer token }
- Response: { success }
```

### YouTube Integration API
```
POST /api/youtube/extract
- 유튜브 메타데이터 추출
- Headers: { Authorization: Bearer token }
- Body: { youtubeUrl }
- Response: { 
    success, 
    metadata: { 
      title, 
      thumbnail, 
      script?, 
      tags,
      hasScript: boolean 
    } 
  }
```

### AI Service API
```
POST /api/ai/summarize
- 스크립트 AI 요약 생성
- Headers: { Authorization: Bearer token }
- Body: { script }
- Response: { success, summary?, error? }
```

## Unit 4: Card Search & Display

### Search Service API
```
GET /api/cards
- 카드 목록 조회 (페이징, 정렬)
- Headers: { Authorization: Bearer token }
- Query: { page?, limit?, sortBy?, categoryId?, search?, tags? }
- Response: { cards: [...], totalCount, hasMore }

GET /api/search/suggestions
- 검색 자동완성 제안
- Headers: { Authorization: Bearer token }
- Query: { query }
- Response: { suggestions: [{ type, value }] }

GET /api/tags
- 사용자 태그 목록
- Headers: { Authorization: Bearer token }
- Response: { tags: [{ name, count }] }
```

## Unit 5: Card Sharing

### Sharing Service API
```
POST /api/cards/:id/share
- 카드 공유 링크 생성
- Headers: { Authorization: Bearer token }
- Response: { success, shareUrl, expiresAt }

GET /api/shared/:shareId
- 공유 카드 조회 (인증 불필요)
- Response: { 
    success, 
    card: { title, thumbnail, summary, youtubeUrl },
    isExpired: boolean 
  }

POST /api/shared/:shareId/save
- 공유 카드를 내 계정에 저장
- Headers: { Authorization: Bearer token }
- Response: { success, card?, alreadyExists? }
```

## Unit 6: User Experience & UI

### System Service API
```
GET /api/system/health
- 시스템 상태 확인
- Response: { status, services: { auth, database, youtube, ai } }

GET /api/system/config
- 클라이언트 설정 정보
- Response: { 
    supportedLanguages: ['ko', 'en'],
    maxFileSize,
    sessionTimeout 
  }
```

## 공통 응답 형식

### 성공 응답
```json
{
  "success": true,
  "data": { ... },
  "message": "Success message"
}
```

### 오류 응답
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Error description",
    "details": { ... }
  }
}
```

## 인증 및 권한

- 모든 보호된 엔드포인트는 `Authorization: Bearer <token>` 헤더 필요
- JWT 토큰 기반 인증
- 토큰 만료 시간: 7일 (활동 시 자동 연장)
- 세션 만료 시 401 Unauthorized 응답

## 오류 코드

```
AUTH_001: Invalid credentials
AUTH_002: Token expired
AUTH_003: Account not found
AUTH_004: Email already exists
CARD_001: Card not found
CARD_002: Invalid YouTube URL
CARD_003: YouTube API error
CATEGORY_001: Category not found
CATEGORY_002: Category not empty
CATEGORY_003: Category name already exists
CATEGORY_004: Category limit exceeded
CATEGORY_005: Invalid category name format
CATEGORY_006: Cannot delete system category
CATEGORY_007: Cannot move to descendant category
CATEGORY_008: Maximum hierarchy level exceeded
CATEGORY_009: Cannot delete category with subcategories
SHARE_001: Share link expired
SHARE_002: Share link not found
AI_001: AI service unavailable
AI_002: Script too short for summary
```
