# Integration Contract

## 개요
각 단위(Unit) 간의 통합을 위한 API 엔드포인트와 메소드를 정의합니다.

## Unit 1: User Authentication & Profile Management

### Authentication Service API
```
POST /api/auth/register
- 이메일 회원가입 요청
- Body: { email, gender?, birthYear? }
- Response: { success, message }

POST /api/auth/verify-registration
- 회원가입 인증 코드 확인
- Body: { email, verificationCode }
- Response: { success, token, user }

POST /api/auth/login
- 로그인 요청 (인증 코드 발송)
- Body: { email }
- Response: { success, message }

POST /api/auth/verify-login
- 로그인 인증 코드 확인
- Body: { email, verificationCode }
- Response: { success, token, user }

POST /api/auth/logout
- 로그아웃
- Headers: { Authorization: Bearer token }
- Response: { success }

POST /api/auth/refresh-session
- 세션 자동 연장
- Headers: { Authorization: Bearer token }
- Response: { success, newToken }

DELETE /api/auth/account
- 회원 탈퇴
- Headers: { Authorization: Bearer token }
- Response: { success }
```

### Profile Service API
```
GET /api/profile
- 프로필 정보 조회
- Headers: { Authorization: Bearer token }
- Response: { user: { email, gender, birthYear, language } }

PUT /api/profile
- 프로필 정보 수정
- Headers: { Authorization: Bearer token }
- Body: { gender?, birthYear?, language? }
- Response: { success, user }
```

## Unit 2: Category Management

### Category Service API
```
GET /api/categories
- 사용자 카테고리 목록 조회
- Headers: { Authorization: Bearer token }
- Response: { categories: [{ id, name, cardCount, isDeletable }] }

POST /api/categories
- 새 카테고리 생성
- Headers: { Authorization: Bearer token }
- Body: { name }
- Response: { success, category: { id, name } }

PUT /api/categories/:id
- 카테고리 이름 수정
- Headers: { Authorization: Bearer token }
- Body: { name }
- Response: { success, category }

DELETE /api/categories/:id
- 카테고리 삭제 (빈 카테고리만)
- Headers: { Authorization: Bearer token }
- Response: { success }
```

## Unit 3: Card Creation & Management

### Card Service API
```
POST /api/cards
- 새 카드 생성
- Headers: { Authorization: Bearer token }
- Body: { contentUrl, categoryId, memo? }
- Response: { success, card: { id, status, message } }

GET /api/cards/:id
- 카드 상세 조회
- Headers: { Authorization: Bearer token }
- Response: { card: { id, title, thumbnail, script, summary, tags, memo, category, is_favorite, favorited_at } }

PUT /api/cards/:id
- 카드 정보 수정
- Headers: { Authorization: Bearer token }
- Body: { memo?, tags?, categoryId?, isPublic? }
- Response: { success, card }

POST /api/cards/:id/favorite
- 카드 즐겨찾기 토글
- Headers: { Authorization: Bearer token }
- Response: { success, is_favorite, message }

POST /api/cards/:id/public
- 카드 공개 설정 토글
- Headers: { Authorization: Bearer token }
- Response: { success, is_public, message }

DELETE /api/cards/:id
- 카드 삭제
- Headers: { Authorization: Bearer token }
- Response: { success }

GET /api/cards
- 사용자 카드 목록 조회 (커서 기반 페이지네이션)
- Headers: { Authorization: Bearer token }
- Query: { categoryId?, favoritesOnly?, cursor?, limit? }
- Response: { cards: [...], nextCursor?, hasMore }
- Response: { success }
```

### YouTube Integration API
```
POST /api/youtube/extract
- 유튜브 메타데이터 추출
- Headers: { Authorization: Bearer token }
- Body: { youtubeUrl }
- Response: { 
    success, 
    metadata: { 
      title, 
      thumbnail, 
      script?, 
      tags,
      hasScript: boolean 
    } 
  }
```

### AI Service API
```
POST /api/ai/summarize
- 스크립트 AI 요약 생성
- Headers: { Authorization: Bearer token }
- Body: { script }
- Response: { success, summary?, error? }
```

## Unit 4: Card Search & Display

### My Cards Service API (커서 기반 페이징)
```
GET /api/my-cards
- 내 카드 목록 조회 (커서 기반 페이징)
- Headers: { Authorization: Bearer token }
- Query: { cursor?, limit?, categoryId?, search?, tag? }
- Response: { cards: [...], nextCursor?, hasMore }

GET /api/my-cards/favorites
- 내 즐겨찾기 카드 목록 조회
- Headers: { Authorization: Bearer token }
- Query: { cursor?, limit? }
- Response: { cards: [...], nextCursor?, hasMore }
```

### Public Cards Service API (오프셋 기반 페이징)
```
GET /api/public-cards
- 공개 카드 검색 (오프셋 기반 페이징)
- Headers: { Authorization: Bearer token }
- Query: { page?, limit?, search?, tag? }
- Note: search와 tag는 동시 사용 불가
- Response: { cards: [...], totalCount, currentPage, totalPages }

POST /api/public-cards/:id/save
- 공개 카드를 내 계정에 독립적으로 복사 저장
- Headers: { Authorization: Bearer token }
- Body: { categoryId? } // 미제공 시 "공유받은 카드" 카테고리 기본 사용
- Response: { success, newCard?, alreadyExists? }
- Note: 원본과 완전히 독립된 새 카드로 생성, 원본 변경사항 반영 안됨
```

### Search Suggestions API
```
GET /api/search/suggestions
- 검색 자동완성 제안
- Headers: { Authorization: Bearer token }
- Query: { query, scope? } // scope: 'my' | 'public'
- Response: { suggestions: [{ type, value }] }

GET /api/tags
- 태그 목록 (내 카드 또는 공개 카드)
- Headers: { Authorization: Bearer token }
- Query: { scope? } // scope: 'my' | 'public'
- Response: { tags: [{ name, count }] }
```

## Unit 5: Card Sharing

### Sharing Service API
```
POST /api/cards/:id/share
- 카드 공유 링크 생성
- Headers: { Authorization: Bearer token }
- Response: { success, shareUrl, expiresAt }

GET /api/shared/:shareId
- 공유 카드 조회 (인증 불필요)
- Response: { 
    success, 
    card: { title, thumbnail, summary, youtubeUrl },
    isExpired: boolean 
  }

POST /api/shared/:shareId/save
- 공유 카드를 내 계정에 독립적으로 복사 저장
- Headers: { Authorization: Bearer token }
- Response: { success, newCard?, alreadyExists? }
- Note: 원본과 완전히 독립된 새 카드로 생성
```

## Unit 6: User Experience & UI

### System Service API
```
GET /api/system/health
- 시스템 상태 확인
- Response: { status, services: { auth, database, youtube, ai } }

GET /api/system/config
- 클라이언트 설정 정보
- Response: { 
    supportedLanguages: ['ko', 'en'],
    maxFileSize,
    sessionTimeout 
  }
```

## 공통 응답 형식

### 성공 응답
```json
{
  "success": true,
  "data": { ... },
  "message": "Success message"
}
```

### 오류 응답
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Error description",
    "details": { ... }
  }
}
```

## 인증 및 권한

- 모든 보호된 엔드포인트는 `Authorization: Bearer <token>` 헤더 필요
- JWT 토큰 기반 인증
- 토큰 만료 시간: 7일 (활동 시 자동 연장)
- 세션 만료 시 401 Unauthorized 응답

## 오류 코드

```
AUTH_001: Invalid credentials
AUTH_002: Token expired
AUTH_003: Account not found
AUTH_004: Email already exists
CARD_001: Card not found
CARD_002: Invalid YouTube URL
CARD_003: YouTube API error
CARD_004: Duplicate card exists
CARD_005: Script too long for summary
CARD_006: Summary generation failed
CARD_007: Thumbnail processing failed
CARD_008: Card creation in progress
CARD_009: Invalid card status transition
CATEGORY_001: Category not found
CATEGORY_002: Category not empty
CATEGORY_003: Category name already exists
CATEGORY_004: Category limit exceeded
CATEGORY_005: Invalid category name format
CATEGORY_006: Cannot delete system category
CATEGORY_007: Cannot move to descendant category
CATEGORY_008: Maximum hierarchy level exceeded
CATEGORY_009: Cannot delete category with subcategories
SEARCH_001: Invalid search criteria
SEARCH_002: Search query too short
SEARCH_003: Search query too long
SEARCH_004: Invalid tag format
SEARCH_005: Category not accessible
SEARCH_006: Public card not found
SEARCH_007: Card already saved
SEARCH_008: Save permission denied
SEARCH_009: Search service unavailable
SEARCH_010: Invalid pagination parameters
SHARE_001: Share link expired
SHARE_002: Share link not found
SHARE_003: Invalid share token format
SHARE_004: Invalid expiration date
SHARE_005: Invalid share URL format
SHARE_006: Invalid metadata format
SHARE_007: Share link creation failed
SHARE_008: Card not shareable
SHARE_009: Share link access denied
SHARE_010: Metadata generation failed
AI_001: AI service unavailable
AI_002: Script too short for summary
```
